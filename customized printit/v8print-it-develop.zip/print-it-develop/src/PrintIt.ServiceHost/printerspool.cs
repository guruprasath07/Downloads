using System;
using System.Collections;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;

namespace PrintSpoolerAPIExample
{

    public class PrintSpoolerApi
    {
        [DllImport("winspool.drv", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool OpenPrinter(
            [MarshalAs(UnmanagedType.LPTStr)]
            string printerName,
            out IntPtr printerHandle,
            PrinterDefaults printerDefaults);

        [DllImport("winspool.drv", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool GetPrinter(
            IntPtr printerHandle,
            int level,
            IntPtr printerData,
            int bufferSize,
            ref int printerDataSize);

        [DllImport("winspool.drv", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool GetDefaultPrinter(
          StringBuilder buffer,
          ref int bufferSize);


        [DllImport("winspool.drv", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool ClosePrinter(
            IntPtr printerHandle);

        [StructLayout(LayoutKind.Sequential)]
        public struct PrinterDefaults
        {
            public IntPtr PDatatype;
            public IntPtr PDevMode;
            public int DesiredAccess;
        }

        public enum PrinterProperty
        {
            ServerName,
            PrinterName,
            ShareName,
            PortName,
            DriverName,
            Comment,
            Location,
            PrintProcessor,
            Datatype,
            Parameters,
            Attributes,
            Priority,
            DefaultPriority,
            StartTime,
            UntilTime,
            Status,
            Jobs,
            AveragePpm
        };

        public struct PrinterInfo2
        {
            [MarshalAs(UnmanagedType.LPTStr)]
            public string ServerName;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string PrinterName;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string ShareName;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string PortName;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string DriverName;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string Comment;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string Location;
            public IntPtr DevMode;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string SepFile;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string PrintProcessor;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string Datatype;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string Parameters;
            public IntPtr SecurityDescriptor;
            public uint Attributes;
            public uint Priority;
            public uint DefaultPriority;
            public uint StartTime;
            public uint UntilTime;
            public uint Status;
            public uint Jobs;
            public uint AveragePpm;
        }

        public static bool IsDefaultPrinterAssigned()
        {
            //initialise size at 0, used to determine size of the buffer
            int size = 0;

            //for first call provide a null StringBuilder to and 0 size to determine buffer size
            //return value will be false, as the call actually fails internally setting the size to the size of the buffer
            GetDefaultPrinter(null, ref size);

            if (size != 0)
            {
                //default printer set
                return true;
            }

            return false;
        }

        public static string GetDefaultPrinterName()
        {
            //initialise size at 0, used to determine size of the buffer
            int size = 0;

            //for first call provide a null StringBuilder to and 0 size to determine buffer size
            //return value will be false, as the call actually fails internally setting the size to the size of the buffer
            GetDefaultPrinter(null, ref size);

            if (size == 0)
            {
                //no default printer set
                return "";
            }

            StringBuilder printerNameStringBuilder = new StringBuilder(size);

            bool success = GetDefaultPrinter(printerNameStringBuilder, ref size);

            if (!success)
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }

            return printerNameStringBuilder.ToString();
        }

        public static PrinterInfo2 GetPrinterProperty(string printerUncName)
        {
            var printerInfo2 = new PrinterInfo2();

            var pHandle = new IntPtr();
            var defaults = new PrinterDefaults();
            try
            {
                //Open a handle to the printer
                bool ok = OpenPrinter(printerUncName, out pHandle, defaults);

                if (!ok)
                {
                    //OpenPrinter failed, get the last known error and thrown it
                    throw new Win32Exception(Marshal.GetLastWin32Error());
                }

                //Here we determine the size of the data we to be returned
                //Passing in 0 for the size will force the function to return the size of the data requested
                int actualDataSize = 0;
                GetPrinter(pHandle, 2, IntPtr.Zero, 0, ref actualDataSize);

                int err = Marshal.GetLastWin32Error();

                if (err == 122)
                {
                    if (actualDataSize > 0)
                    {
                        //Allocate memory to the size of the data requested
                        IntPtr printerData = Marshal.AllocHGlobal(actualDataSize);
                        //Retrieve the actual information this time
                        GetPrinter(pHandle, 2, printerData, actualDataSize, ref actualDataSize);

                        //Marshal to our structure
                        printerInfo2 = (PrinterInfo2)Marshal.PtrToStructure(printerData, typeof(PrinterInfo2));
                        //We've made the conversion, now free up that memory
                        Marshal.FreeHGlobal(printerData);
                    }
                }
                else
                {
                    throw new Win32Exception(err);
                }

                return printerInfo2;
            }
            finally
            {
                //Always close the handle to the printer
                ClosePrinter(pHandle);
            }
        }
    }
}
