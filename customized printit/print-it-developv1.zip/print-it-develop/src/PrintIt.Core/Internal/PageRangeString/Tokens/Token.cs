﻿namespace PrintIt.Core.Internal.PageRangeString.Tokens
{
    internal abstract class Token
    {
    }
}
