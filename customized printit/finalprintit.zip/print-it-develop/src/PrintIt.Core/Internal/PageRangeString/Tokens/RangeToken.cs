namespace PrintIt.Core.Internal.PageRangeString.Tokens
{
    internal sealed class RangeToken : Token
    {
        public override string ToString() => "-";
    }
}
