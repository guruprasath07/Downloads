using System;
using System.ComponentModel.DataAnnotations;
using System.Drawing.Printing;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PrintIt.Core;

namespace PrintIt.ServiceHost.Controllers
{
    [ApiController]
    [Route("print")]
    public class PrintController : ControllerBase
    {
        private readonly IPdfPrintService _pdfPrintService;

        public PrintController(IPdfPrintService pdfPrintService)
        {
            _pdfPrintService = pdfPrintService;
        }

        [HttpPost]
        [Route("from-pdf")]
      //  [EnableCors]
        public async Task<IActionResult> PrintFromPdf([FromForm] PrintFromTemplateRequest request)
        {
            await using Stream pdfStream = request.PdfFile.OpenReadStream();
            if (string.IsNullOrEmpty(request.PrinterPath))
            {
                PrinterSettings ps = new PrinterSettings();
                request.PrinterPath = ps.PrinterName;
            }
            _pdfPrintService.Print(pdfStream, request.PrinterPath, request.PageRange);
            return Ok();
        }
        [HttpPost]
        [Route("from-base64")]
      //  [EnableCors]
        public  IActionResult PrintFrombase64([FromForm] PrintFromTemplateRequestNew request)
        {

            byte[] bytes = Convert.FromBase64String(request.PdfBase64);
            MemoryStream ms = new MemoryStream(bytes);
            ms.Seek(0, SeekOrigin.Begin);
            if (string.IsNullOrEmpty(request.PrinterPath))
            {
                PrinterSettings ps = new PrinterSettings();
                request.PrinterPath = ps.PrinterName;
            }
            _pdfPrintService.Print(ms, request.PrinterPath, request.PageRange);
            return Ok();
        }
    }

    public sealed class PrintFromTemplateRequest
    {
        [Required]
        public IFormFile PdfFile { get; set; }

     
        public string PrinterPath { get; set; }

        public string PageRange { get; set; }
    }

    public sealed class PrintFromTemplateRequestNew
    {
        [Required]
        public string PdfBase64 { get; set; }
        public string PrinterPath { get; set; }

        public string PageRange { get; set; }



    }
}
