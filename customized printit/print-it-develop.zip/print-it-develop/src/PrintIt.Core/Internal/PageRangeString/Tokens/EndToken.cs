namespace PrintIt.Core.Internal.PageRangeString.Tokens
{
    internal sealed class EndToken : Token
    {
        public override string ToString() => "[END]";
    }
}
