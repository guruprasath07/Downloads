yajsw-stable-12.16

bug and security update

    * Security update: groovy, velocity, netty, CryptoConstants
    * logging in GInterpolator
    * NPE in DateFileHandler
    * error parsing java command line
    * sigar crashes jdk11 -> revert to jna
    * bug: groovy script deadlock

Note: this is the last release to support java 1.7. The next relase will support JDK8 - JDK 14
